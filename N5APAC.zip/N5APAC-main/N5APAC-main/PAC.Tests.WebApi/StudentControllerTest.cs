﻿namespace PAC.Tests.WebApi;
using System.Collections.ObjectModel;

using System.Data;
using Moq;
using PAC.IBusinessLogic;
using PAC.Domain;
using PAC.WebAPI;
using Microsoft.AspNetCore.Mvc;
using PAC.WebAPI.Models;

[TestClass]
public class StudentControllerTest
{
    private Mock<IStudentLogic> mockStudentLogic;
    private List<Student> expectedStudents;


    [TestInitialize]
    public void Initialize()
    {
        mockStudentLogic = new Mock<IStudentLogic>(MockBehavior.Strict);
        expectedStudents = new List<Student>
        {
            new Student(1, "test"),
        };
    }
    [TestMethod]
    public void PostStudentOk()
    {
        Student student = new Student(1, "test");

        mockStudentLogic.Setup(x => x.InsertStudents(student)).Returns(student);

        StudentController controller = new StudentController(mockStudentLogic.Object);

        var result = controller.Post(student);
        var parsedResult = result as OkObjectResult;

    }

    public void PostStudentFail()
    {
        Student student = new Student(1, "test");

        mockStudentLogic.Setup(x => x.InsertStudents(student)).Returns((Student)null);

        StudentController controller = new StudentController(mockStudentLogic.Object);

        var result = controller.Post(student);
        var parsedResult = result as BadRequestObjectResult;
        var body = parsedResult.Value as IEnumerable<StudentBasicInfo>;

        CollectionAssert.AreEqual(expectedStudents, body.ToList());
        mockStudentLogic.VerifyAll();
    }
}
