﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PAC.Domain;
using PAC.IBusinessLogic;
using PAC.WebAPI.Filters;
using PAC.WebAPI.Models;

namespace PAC.WebAPI
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly IStudentLogic students;
        public StudentController(IStudentLogic students) : base()
        {
            this.students = students;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var parsedStudents = students.GetStudents().ToList().Select(c => new StudentBasicInfo(c));
            return Ok(parsedStudents);
        }

        [HttpGet("{id}")]
        public IActionResult Get([FromRoute] int id)
        {
            var parsedStudents = students.GetStudentById(id).Name;
            return Ok(parsedStudents);
        }

        [HttpPost]
        public IActionResult Post([FromBody] StudentModel student)
        {
            return Ok();
        }
    }
}
