﻿using PAC.Domain;

namespace PAC.WebAPI.Models
{
    public class StudentModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Student ToEntity()
        {
            Student student = new Student(Id,Name);

            return student;
        }
    }
}
