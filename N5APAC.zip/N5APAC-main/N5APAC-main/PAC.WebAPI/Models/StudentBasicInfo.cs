﻿using PAC.Domain;

namespace PAC.WebAPI.Models
{
    public class StudentBasicInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public StudentBasicInfo(Student student)
        {
            Id = student.Id;
            Name = student.Name;
        }
    }
}
